<header class="app-header navbar">
    <button class="navbar-toggler sidebar-toggler d-lg-none mr-auto" type="button" data-toggle="sidebar-show">
        <span class="navbar-toggler-icon"></span>
    </button>

    <button class="navbar-toggler sidebar-toggler d-md-down-none" type="button" data-toggle="sidebar-lg-show">
        <span class="navbar-toggler-icon"></span>
    </button>
    <a class="navbar-brand" href="#">
        <!-- <img class="navbar-brand-full" src="<?=base_url();?>assets/img/kjsce-logo-2.png" width="120" height="45" alt="CoreUI Logo"> -->
        <p class="h5">KJSCE Feedback</p>
    </a>
    <ul class="nav navbar-nav ml-auto">
    
    </ul>

</header>